const { app, BrowserWindow, ipcMain } = require('electron')
const path = require('path')
const http = require('http');
const fs = require('fs');

ipcMain.on("window-new", (e, data = { videoUrl: '', videoName: '' }) => {
  console.log(data, '==data');

  if (!data.videoUrl || !data.videoName) return;

  // 保存下载的视频的本地路径
  const downloadPath = path.join(__dirname, data.videoName);

  const fileStream = fs.createWriteStream(downloadPath);

  http.get(data.videoUrl, (response) => {
    response.pipe(fileStream);

    response.on('end', () => {
      fileStream.close();
      console.log('视频下载完成');
    });
  }).on('error', (error) => {
    console.error(`视频下载错误：${error.message}`);
  });
});

function createWindow() {
  const win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  })

  win.loadURL('http://127.0.0.1:3304/')
}

app.whenReady().then(() => {
  createWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})