<script setup>
import Download from './components/download.vue'
</script>

<template>
  <Download />
</template>