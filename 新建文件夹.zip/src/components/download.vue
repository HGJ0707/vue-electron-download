<template>
  <div class="box">
    <a-space wrap>
      <a-button type="primary" danger>清除参数</a-button>
      <a-button type="primary" @click="download('style1')">下载通道一</a-button>
      <a-button type="primary" @click="download('style2')">下载通道二</a-button>
    </a-space>
    <a-textarea v-model:value="params" class="params" :rows="20" />
  </div>
</template>

<script setup>
import { ref } from "vue";
import { useIpcRenderer } from "@vueuse/electron";

const ipcRenderer = useIpcRenderer();

const params = ref("");

const download = async (style = "style1") => {
  // console.log(params.value);

  const videoUrls = await parseParams();
  console.log(videoUrls, "=====urls");
};

async function parseParams() {
  console.log(params.value, "===params.value");
  const videoUrls = [];
  const aaa = params.value;

  console.log(aaa);
  const aa = aaa?.replace(/\\" | \\n/g, "");
  console.log(aa, '====aa');
  // console.log(JSON.parse(params.value?.replace('\"', '')));
  // params.value?.aweme_list[0]?.forEach((videoItem) => {
  //   videoUrls.push(videoItem?.item?.video?.play_addr?.url_list);
  // });
  // console.log(JSON.parse(aa));

  // console.log(jsonParams?.aweme_list, "== params.value?.aweme_list");
  return videoUrls;
}

const notificationMain = () => {
  ipcRenderer.send("window-new", {
    videoUrl:
      "http://v26-web.douyinvod.com/f5b62b9c40cb8b5436c39292fa655a4f/64e328e4/video/tos/cn/tos-cn-ve-15c001-alinc2/0a55ff4a59c749c0969a2ec42791cd3d/?a=6383\u0026ch=10010\u0026cr=3\u0026dr=0\u0026lr=all\u0026cd=0%7C0%7C0%7C3\u0026cv=1\u0026br=1227\u0026bt=1227\u0026cs=0\u0026ds=3\u0026ft=bvTKJbQQqU-mfJ4ZPo0OW_EklpPiX7-l6MVJEfa1_pvPD-I\u0026mime_type=video_mp4\u0026qs=0\u0026rc=MzQ7aWlpZGg4MzdmNGk4M0BpamV4cTk6Zjw1ZDMzNGkzM0AyNDExM19iXl4xYzZiMy0xYSMtXjBicjRvZDNgLS1kLS9zcw%3D%3D\u0026btag=e00010000\u0026dy_q=1692605125\u0026l=202308211605257E7C948770035401816D",
    videoName: "123.mp4",
  }); // 向主进程通信
};
</script>

<style scoped>
.box {
  max-width: 1000px;
  margin: 0 auto;
}

.params {
  margin-top: 30px;
}
</style>
<!--
aweme_list[]
item{}
video{}
play_addr{}
url_list[] -->
